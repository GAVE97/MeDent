@extends('layouts.appComun')
@section('title', 'Editar cita')

@section('content')
<div class="col align-self-center">
    <h2>El perfil de usuario no cuenta con la autorización para acceder a estos datos, por favor retorne a la pagina de inicio dando clic al enlace.</h2>
    <a class="navbar-brand" href="/">MeDent</a>
</div>
@endsection